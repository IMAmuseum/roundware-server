django-admin-bootstrapped
=========================


This is a Django-1.9 compatible version of https://github.com/django-admin-bootstrapped/django-admin-bootstrapped

Installation
------------

```bash
pip install -e git+git://github.com/cesar57927/django-admin-bootstrapped-1.9-compatible.git@master#egg=django_admin_bootstrapped
```
 
 OR
 
```bash
git clone https://github.com/cesar57927/django-admin-bootstrapped-1.9-compatible
cd  django-admin-bootstrapped-1.9-compatible
pip install -e .
```
